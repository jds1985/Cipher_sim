"""
HLC v3 - 7-Tier Hierarchical Latent Controller (Deep Carrier Edition)
Copyright 2026 Cipher CTS. All Rights Reserved.
Licensed under the Cipher CTS Proprietary Evaluation License (see LICENSE):
non-commercial evaluation only; commercial use requires a paid license from Cipher CTS.

Local, offline, CPU-only remaining-useful-life (RUL) service for NASA C-MAPSS FD001-style input.
Listens on 127.0.0.1 only. Clients must normalize input with norm_stats.json (see README.md).

Changes vs. the earlier v3 service file (the model classes are unchanged):
  * weights are loaded from next to this file, and the service refuses to start without them
  * HLC_ALLOWED_ORIGINS env var is honored; GET /health added; GET / kept
  * HLC_OJAS_MODE: "fresh" (default) starts every /predict at ojas=1.0 (matches training);
    "carry" restores the earlier behavior where the Ojas ledger accumulates across calls.
    Measured on real data, carrying Ojas lowers accuracy (see README.md).
  * runs directly with `python bio_engine_service_v3.py` (127.0.0.1:8000)
"""

import os
import time
import math
import json
import torch
import torch.nn as nn
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Optional

# --- PRODUCTION ORIGIN CONFIGURATION ---
DEFAULT_ORIGINS = [
    "http://localhost:3000",
    "http://127.0.0.1:3000",
    "https://ciphercts.com",
    "https://www.ciphercts.com"
]
# HLC_ALLOWED_ORIGINS="https://a.example,https://b.example" replaces the default list
_env_origins = os.environ.get("HLC_ALLOWED_ORIGINS", "").strip()
ALLOWED_ORIGINS = [o.strip() for o in _env_origins.split(",") if o.strip()] if _env_origins else DEFAULT_ORIGINS

app = FastAPI(title="Cipher CTS HLC v3 Engine", version="3.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- ARCHITECTURAL CORE: HLC v3 ---

class DynamicMeridianGate(nn.Module):
    """Prunes invariant noise channels while routing 14 active sensory paths."""
    def __init__(self, in_channels: int = 21, active_channels: int = 14):
        super().__init__()
        # Invariant indices in standard C-MAPSS FD001 (0-indexed: 0, 4, 5, 9, 15, 17, 18)
        self.active_mask = torch.tensor([
            False, True, True, True, False, False, True, 
            True, True, False, True, True, True, True, 
            True, False, True, False, False, True, True
        ], dtype=torch.bool)
        self.proj = nn.Linear(active_channels, 32)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x shape: [batch, time, 21]
        active_x = x[:, :, self.active_mask]
        return torch.tanh(self.proj(active_x))

class MultiScaleRootIngestion(nn.Module):
    """Processes temporal dynamics across Micro (1x), Meso (3x), and Macro (6x) strides."""
    def __init__(self, in_features: int = 32, latent_dim: int = 48):
        super().__init__()
        self.conv_micro = nn.Conv1d(in_features, latent_dim // 3, kernel_size=3, dilation=1, padding=1)
        self.conv_meso  = nn.Conv1d(in_features, latent_dim // 3, kernel_size=3, dilation=3, padding=3)
        self.conv_macro = nn.Conv1d(in_features, latent_dim // 3, kernel_size=3, dilation=6, padding=6)
        self.fuse = nn.Linear(latent_dim, latent_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Transpose for Conv1d: [batch, features, time]
        x_t = x.transpose(1, 2)
        micro = self.conv_micro(x_t)
        meso  = self.conv_meso(x_t)
        macro = self.conv_macro(x_t)
        combined = torch.cat([micro, meso, macro], dim=1).transpose(1, 2)
        return torch.relu(self.fuse(combined))

class SushumnaSpineV3(nn.Module):
    def __init__(self):
        super().__init__()
        self.meridian = DynamicMeridianGate()
        self.root = MultiScaleRootIngestion()
        
        # Intermediate Tiers: Sacral (1), Solar Plexus (2), Heart (3), Throat (4), Ajna (5)
        self.intermediate_spine = nn.GRU(input_size=48, hidden_size=64, num_layers=2, batch_first=True)
        
        # Tier 6: Crown Projector
        self.crown_head = nn.Sequential(
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, 1)
        )
        
        # Bidirectional Downward Constraint Channel
        self.top_down_gate = nn.Linear(1, 64)

    def forward(self, x: torch.Tensor, carryover_ojas: float) -> tuple:
        # Step 1: Meridian routing
        routed = self.meridian(x)
        
        # Step 2: Multi-scale temporal absorption at Root
        temporal_features = self.root(routed)
        
        # Step 3: Ascending carrier wave along the spine
        gru_out, h_n = self.intermediate_spine(temporal_features)
        spine_state = h_n[-1] # [batch, 64]
        
        # Step 4: Crown prediction
        raw_rul = self.crown_head(spine_state).squeeze(-1)
        
        # Step 5: Top-down feedback sweep
        prior = torch.sigmoid(self.crown_head[0](spine_state))
        
        # Step 6: Ojas Ledger update (Physical Monotonicity Enforcement)
        # Wear increases friction monotonically: friction delta = relu(scaled_fatigue)
        wear_delta = torch.clamp((125.0 - raw_rul) / 100.0, min=0.0).item()
        new_ojas = max(carryover_ojas, carryover_ojas + (wear_delta * 0.05))
        
        # Apply Ojas penalty to raw RUL
        ojas_penalty = (new_ojas - 1.0) * 2.5
        adjusted_rul = torch.clamp(raw_rul - ojas_penalty, min=0.0, max=125.0)
        
        return adjusted_rul, new_ojas

# --- INITIALIZATION & STATE ---
device = torch.device("cpu")
model = SushumnaSpineV3().to(device)
HERE = os.path.dirname(os.path.abspath(__file__))
WEIGHTS_PATH = os.path.join(HERE, "bio_engine_weights_nasa_v3.pt")
if not os.path.isfile(WEIGHTS_PATH):
    raise RuntimeError(f"Weights file not found: {WEIGHTS_PATH}")
model.load_state_dict(torch.load(WEIGHTS_PATH, map_location=device, weights_only=True))
print(f"Loaded weights from {WEIGHTS_PATH}")
model.eval()
with torch.no_grad():
    model(torch.zeros((1, 30, 21), dtype=torch.float32).to(device), 1.0)

OJAS_MODE = os.environ.get("HLC_OJAS_MODE", "fresh").strip().lower()
if OJAS_MODE not in ("fresh", "carry"):
    raise RuntimeError("HLC_OJAS_MODE must be 'fresh' or 'carry'")

# Persistent In-Memory Ledger (Stateful across inference calls)
METABOLIC_LEDGER = {
    "ojas": 1.0,
    "total_inferences": 0
}

class TelemetryPayload(BaseModel):
    window: List[List[float]] = Field(..., description="30 rows of 21 sensor floats")

class PredictionResponse(BaseModel):
    rul: float
    status: str
    ojas: float
    inference_ms: float
    engine_version: str

@app.get("/")
@app.get("/health")
def health_check():
    return {
        "status": "ONLINE",
        "engine": "HLC v3 (Deep Carrier Controller)",
        "architecture": "Multi-Scale Sushumna Spine + Dynamic Meridian Routing",
        "silicon": "local_cpu",
        "ojas_state": round(METABOLIC_LEDGER["ojas"], 4),
        "ojas_mode": OJAS_MODE
    }

@app.post("/predict", response_model=PredictionResponse)
def predict_lifecycle(payload: TelemetryPayload):
    t_start = time.perf_counter()
    
    if len(payload.window) != 30 or any(len(row) != 21 for row in payload.window):
        raise HTTPException(
            status_code=422, 
            detail="Payload must be exactly 30 cycles by 21 sensor channels."
        )
    
    tensor_in = torch.tensor([payload.window], dtype=torch.float32).to(device)
    
    start_ojas = 1.0 if OJAS_MODE == "fresh" else METABOLIC_LEDGER["ojas"]
    with torch.no_grad():
        predicted_rul, updated_ojas = model(tensor_in, start_ojas)
        
    METABOLIC_LEDGER["ojas"] = updated_ojas
    METABOLIC_LEDGER["total_inferences"] += 1
    
    rul_val = round(float(predicted_rul.item()), 2)
    ojas_val = round(updated_ojas, 4)
    
    # Safety Classification
    if rul_val <= 25.0:
        status = "CRITICAL"
    elif rul_val <= 50.0:
        status = "WARNING"
    else:
        status = "NOMINAL"
        
    t_elapsed = round((time.perf_counter() - t_start) * 1000, 2)
    
    return PredictionResponse(
        rul=rul_val,
        status=status,
        ojas=ojas_val,
        inference_ms=t_elapsed,
        engine_version="3.0.0-deep-carrier"
    )

@app.post("/reset-ojas")
def reset_ledger():
    METABOLIC_LEDGER["ojas"] = 1.0
    return {"status": "SUCCESS", "ojas_reset_to": 1.0}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000, log_level="info")
