# HLC Edge Engine v3 - local evaluation build

Copyright 2026 Cipher CTS. All Rights Reserved. Cipher CTS Proprietary Evaluation License (see LICENSE and NOTICE).
Non-commercial evaluation only. Commercial use requires a paid license from Cipher CTS (team@ciphercts.com).

What it is: a small remaining-useful-life (RUL) model for turbofan engines, served by a local web API.
It runs offline, on the CPU, on your own computer. Your sensor data never leaves the machine.
The engine listens on 127.0.0.1 only. It is tiny (56,577 parameters as the shipped class counts them, of which 128 belong to a layer the forward pass does not use; 56,449 are active; a 234 KB weights file; about 0.8 ms per prediction on a CPU).

## Run it
Needs Linux with Python 3.9 or newer, and internet access for the first run only (to install PyTorch CPU, NumPy, FastAPI, Uvicorn).

    bash run_engine.sh --no-browser

Check it: `curl http://127.0.0.1:8000/health` (the same answer comes from `/`). API docs: http://127.0.0.1:8000/docs
Stop it with Ctrl+C. To call it from a browser page on another site, set `HLC_ALLOWED_ORIGINS="https://site1,https://site2"` before starting (this replaces the default list).

API:
- `POST /predict` with `{"window": [[...21 numbers...] x 30 rows]}`. Returns `rul`, `status` (CRITICAL if RUL <= 25, WARNING if <= 50, else NOMINAL), `ojas`, `inference_ms`.
- `POST /reset-ojas` resets the Ojas ledger to 1.0.
- `GET /health`, `GET /` return status.
- `python example_predict.py PATH/test_FD001.txt 1` shows a full call from raw C-MAPSS rows (the NASA data file is not included).

## Input must be normalized (the engine does NOT do it)
Use `norm_stats.json` (min and max per sensor, fitted on all 100 training engines of train_FD001.txt; no test data):

    x_norm = (x - min) / (max - min + 1e-6)

- 21 sensor columns only (columns 5..25 of a C-MAPSS row, 0-indexed), in sensor order 1..21.
- Sensors listed in `zero_range_sensors` (max == min) are set to exactly 0.0.
- Values are not clipped.
- Window = the last 30 cycles of one engine, oldest first. If an engine has fewer than 30 cycles, repeat its first row at the front. (All 100 FD001 test engines have at least 31 cycles, so no padding was used in the benchmark.)
- Output RUL is in cycles, limited to 0..125 (the model was trained on RUL capped at 125).

## Benchmark (NASA C-MAPSS FD001, measured, not estimated)
Training: the v3 network, trained from scratch on all 100 training engines of train_FD001.txt (RUL capped at 125, 30-cycle windows, MSE loss, AdamW lr 1e-3, weight decay 1e-2, batch 64, input noise 0.02, cosine schedule, a fixed 30 epochs, no early stopping and no validation split).
The training protocol was chosen with 5-fold cross-validation by engine on the training engines (cross-validated RMSE 13.49). The official test set was not used to pick any setting, and each model was scored on it once.
Test: the 100 official engines in test_FD001.txt, last 30-cycle window per engine, Ojas fresh (1.0) for each window, against the official RUL_FD001.txt.
Five training runs (seeds 0 to 4). Mean +/- standard deviation across the runs (n = 5):

| Measure | Result |
|---|---|
| Test RMSE vs official RUL (uncapped), mean of 5 runs | 13.58 +/- 0.35 (about 13.6; per run 14.13, 13.20, 13.63, 13.51, 13.41) |
| Test RMSE vs RUL capped at 125 (secondary) | 12.40 +/- 0.34 |
| NASA PHM08 score vs official RUL (lower is better) | 299.5 +/- 19.1 |
| **The weights in this zip (seed 0, fixed in advance, not chosen by test score)** | **test RMSE 14.13 (14.126), capped 12.96, score 331.6** |
| Average of the 5 runs' predictions (not shipped, 5 models) | test RMSE 13.45, score 293 |
| Speed, one window, one CPU thread (Intel Xeon, 8 vCPU, Python 3.13, torch 2.14 CPU) | about 0.8 ms (mean 0.79 in the benchmark; 0.73 to 0.89 in repeated timings of the shipped class) |

The zip contains the weights of one training run. That run (seed 0) happens to be the highest of the five on the test set (14.13 against a mean of 13.58). Seed 0 was fixed as the default before the test scores were looked at; it was not chosen or swapped by test score.
Expect the shipped weights to score about 14.1 on the FD001 test set, as measured here. The 13.6 figure is the average over the five runs.
Over real HTTP, on all 100 test engines, this service gives RMSE 14.126 and NASA score 331.6, the same as the offline result (largest difference per engine 0.005 cycles, from rounding to 2 decimals).

Imminent failure, measured on real data (7 test engines with true RUL <= 10): mean absolute error 1.44 +/- 0.25 cycles over the 5 runs (1.09 for the shipped weights), and all 7 were predicted <= 25 (CRITICAL) by every run.
That is a very small sample (7 engines). On the 67 test engines with true RUL > 50, none was flagged CRITICAL. On average the model's predictions are about 1.3 cycles above the true RUL (bias), and it over-predicts for about 58% of the test engines, which is the unsafe direction for a maintenance decision.

## Limitations - please read
- This is one data set (simulated turbofans, one operating condition, 100 training engines). It says nothing about other machines or other data. It was trained on FD001 only.
- The test set has only 100 engines. The run-to-run spread is about 0.35 RMSE, and the choice of 100 engines adds more uncertainty that is not in that number.
- These are estimates, not guarantees. Do not use them as the only basis for a safety or maintenance decision. The software is not certified for any purpose.
- The model needs inputs normalized exactly as above. Other normalization will give wrong answers.
- The weights file should be used as shipped.
- Ojas (this engine's wear ledger): the network was trained with a fresh Ojas of 1.0, so this service defaults to `HLC_OJAS_MODE=fresh` (each /predict starts at 1.0, independent of earlier calls). Even then, the Ojas step subtracts at most 0.16 cycles from a prediction.
  `HLC_OJAS_MODE=carry` makes the ledger accumulate across calls. Measured with these weights over the 100 test engines in order: test RMSE 14.13 (fresh) against 14.43 (carry), and the average error on the 7 imminent-failure engines went from 1.09 to 4.0 cycles. Carry mode lowers accuracy.
- Python packages are installed from the internet on first run. After that the engine runs fully offline.
- Verified on: Linux, with run_engine.sh run from an empty folder on two stacks. (1) Python 3.13, torch 2.14.1 CPU, FastAPI 0.162.0, Uvicorn 0.54.0, NumPy 2.5.4. (2) Python 3.9.25, torch 2.8.0 CPU, FastAPI 0.128.8, Uvicorn 0.39.0, NumPy 2.0.2. On Python 3.9 with an old pip, the first torch install step fails and the script retries automatically; this worked. Not tested on other Linux versions, other Python versions, or on GPUs.

## Files
bio_engine_service_v3.py (service and model), bio_engine_weights_nasa_v3.pt (trained weights), norm_stats.json, run_engine.sh, requirements.txt, example_predict.py, LICENSE, NOTICE.
Data source for training and benchmark (not included): NASA C-MAPSS, see NOTICE for the citation.
