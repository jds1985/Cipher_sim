#!/usr/bin/env bash
# Copyright 2026 Cipher CTS. All Rights Reserved.
# Licensed under the Cipher CTS Proprietary Evaluation License (see LICENSE): non-commercial evaluation only.
# run_engine.sh - start the local HLC Edge Engine v3 (offline, CPU-only).
#
#   bash run_engine.sh               set up (first run only), start, wait until healthy
#   bash run_engine.sh --no-browser  do not try to open a browser tab
#
# What it does, in order:
#   1. checks for Python 3.9+            2. creates ./venv if missing
#   3. installs CPU-only PyTorch + numpy fastapi uvicorn -- only if they are not already importable
#   4. starts bio_engine_service_v3.py (listens on 127.0.0.1:8000 ONLY, never on the network)
#   5. waits for http://127.0.0.1:8000/health and tells you when the engine is ready
# Optional environment variables:
#   HLC_TORCH_INDEX=URL     PyTorch wheel index (default: the CPU-only index; falls back to normal PyPI)
#   HLC_ALLOWED_ORIGINS=a,b websites that may call the engine from a browser (CORS; replaces the default list)
#   HLC_OJAS_MODE=fresh|carry  fresh (default): every request starts at Ojas 1.0. carry: Ojas accumulates (see README.md)
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"

HOST="127.0.0.1"
PORT="8000" # fixed: bio_engine_service_v3.py listens on 8000
TORCH_INDEX="${HLC_TORCH_INDEX:-https://download.pytorch.org/whl/cpu}"
OPEN_BROWSER=1
case "${1:-}" in
  "") ;;
  --no-browser) OPEN_BROWSER=0 ;;
  -h | --help) sed -n '2,17p' "${BASH_SOURCE[0]}"; exit 0 ;;
  *) echo "Unknown option: $1 (try --help)" >&2; exit 2 ;;
esac

say() { printf '\n[*] %s\n' "$*"; }
die() { printf '\n[!] ERROR: %s\n' "$*" >&2; exit 1; }

say "Checking Python"
command -v python3 >/dev/null 2>&1 || die "python3 not found. Linux Mint/Ubuntu: sudo apt install python3 python3-venv python3-pip"
python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' ||
  die "Python 3.9 or newer is required (found $(python3 --version 2>&1))."
for f in bio_engine_service_v3.py bio_engine_weights_nasa_v3.pt norm_stats.json requirements.txt; do
  [ -f "$f" ] || die "Missing file next to run_engine.sh: $f"
done

if [ ! -x venv/bin/python ]; then
  say "Creating virtual environment ./venv"
  python3 -m venv venv || die "Could not create a virtual environment. Linux Mint/Ubuntu: sudo apt install python3-venv"
fi
PY="venv/bin/python"

if "$PY" -c "import torch, numpy, fastapi, uvicorn" >/dev/null 2>&1; then
  say "Dependencies already installed - skipping the install step"
else
  say "Installing dependencies (first run only; PyTorch is a large download, a few hundred MB)"
  if ! "$PY" -c "import torch" >/dev/null 2>&1; then
    "$PY" -m pip install torch --index-url "$TORCH_INDEX" ||
      {
        echo "CPU wheel index failed - installing torch's helper packages from PyPI, then retrying the CPU wheel."
        "$PY" -m pip install filelock typing_extensions sympy networkx jinja2 fsspec setuptools &&
          "$PY" -m pip install torch --index-url "$TORCH_INDEX"
      } ||
      {
        echo "CPU wheel index failed again - trying the default PyPI torch instead (may be much larger)."
        "$PY" -m pip install torch || die "Could not install torch. Check your internet connection."
      }
  fi
  "$PY" -m pip install -r requirements.txt || die "pip install failed - see the message above."
fi

if ! "$PY" - "$HOST" "$PORT" <<'PYEOF'; then
import socket, sys
s = socket.socket()
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)  # same as the engine, so a just-stopped engine is not 'in use'
try:
    s.bind((sys.argv[1], int(sys.argv[2])))
except OSError:
    sys.exit(1)
PYEOF
  die "Port $PORT is already in use - is the engine already running? Open http://localhost:$PORT/docs , or stop the other program."
fi

say "Starting the engine on http://$HOST:$PORT (this computer only)"
"$PY" bio_engine_service_v3.py &
ENGINE_PID=$!
trap 'kill "$ENGINE_PID" >/dev/null 2>&1 || true' EXIT INT TERM

READY=0
for _ in $(seq 1 120); do
  kill -0 "$ENGINE_PID" 2>/dev/null || die "The engine stopped while starting. Read the messages above."
  if "$PY" -c "import sys,urllib.request; sys.exit(0 if urllib.request.urlopen('http://$HOST:$PORT/health', timeout=2).status == 200 else 1)" >/dev/null 2>&1; then
    READY=1
    break
  fi
  sleep 1
done
[ "$READY" = 1 ] || die "The engine did not answer on http://$HOST:$PORT/health within 2 minutes."

cat <<MSG

[+] ENGINE IS READY
    Health check : http://localhost:$PORT/health
    API docs     : http://localhost:$PORT/docs   (engine status: http://localhost:$PORT/)
    Leave this window open. Press Ctrl+C to stop the engine (the Ojas ledger lives in memory only).
MSG
if [ "$OPEN_BROWSER" = 1 ]; then
  (xdg-open "http://localhost:$PORT/docs" || open "http://localhost:$PORT/docs") >/dev/null 2>&1 || true
fi
wait "$ENGINE_PID"
