# Copyright 2026 Cipher CTS. All Rights Reserved.
# Licensed under the Cipher CTS Proprietary Evaluation License (see LICENSE): non-commercial evaluation only.
"""Example client: normalize one engine's last 30 cycles with norm_stats.json and ask the local engine for its RUL.

  python example_predict.py PATH_TO_test_FD001.txt ENGINE_ID [http://127.0.0.1:8000]

The data file (NASA C-MAPSS, not included) has 26 whitespace-separated columns:
unit, cycle, 3 settings, 21 sensors. Only the 21 sensor columns are sent to the engine.
"""
import json, os, sys, urllib.request
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))

def normalize(raw21, stats):
    """raw21: (n_cycles, 21) raw sensor values -> normalized, exactly as in training. Not clipped."""
    mn = np.array(stats["min"]); mx = np.array(stats["max"])
    out = (raw21 - mn) / (mx - mn + 1e-6)
    out[:, mx == mn] = 0.0            # sensors with zero range in the training engines are set to 0
    return out

def last_window(x, length=30):
    """Last 30 cycles; if the engine has fewer, repeat its first row at the front."""
    if len(x) >= length:
        return x[-length:]
    return np.vstack([np.repeat(x[:1], length - len(x), 0), x])

def main():
    path, unit = sys.argv[1], int(sys.argv[2])
    base = sys.argv[3] if len(sys.argv) > 3 else "http://127.0.0.1:8000"
    stats = json.load(open(os.path.join(HERE, "norm_stats.json")))
    data = np.loadtxt(path)
    raw = data[data[:, 0] == unit][:, 5:26]
    window = last_window(normalize(raw, stats)).tolist()
    req = urllib.request.Request(base + "/predict", data=json.dumps({"window": window}).encode(),
                                 headers={"Content-Type": "application/json"})
    print(json.loads(urllib.request.urlopen(req, timeout=30).read()))

if __name__ == "__main__":
    main()
