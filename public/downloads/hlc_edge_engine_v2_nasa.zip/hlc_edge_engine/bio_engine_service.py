# © 2026 Cipher CTS. All Rights Reserved.
# Proprietary Evaluation License: see LICENSE.

# =====================================================================================================
# PRODUCTION WEBSITE that may call this engine from a visitor's browser (scheme + host, no trailing slash).
#     Change it here if the site moves; keep exactly one origin on this line.
#     Cipher CTS production site: https://ciphercts.com (the www. address is allowed too, line 11).
#     More sites WITHOUT editing this file:  HLC_ALLOWED_ORIGINS="https://other.example" bash run_engine.sh
#     "*" (any website) is never accepted, here or in HLC_ALLOWED_ORIGINS.
PRODUCTION_SITE_ORIGIN = "https://ciphercts.com"
PRODUCTION_SITE_ORIGIN_WWW = "https://www.ciphercts.com"
# =====================================================================================================

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List
import numpy as np
from test_calibrated_client import LocalBioPredictor

app = FastAPI(title="7-Tier Bio-Energetic Engine API", version="2.0.1")

# --- HLC v1.1 patch (website dashboard support) ---------------------------------------------------
# The original v1 file had no CORS support, so a web page (the dashboard) could not read answers from
# this local engine. This block only adds CORS headers and a "/" -> "/docs" redirect. It does not touch
# the model, the weights, the /health or /predict handlers, or the Ojas state.
# Which websites may call the engine: the defaults below, plus anything in the environment variable
#   HLC_ALLOWED_ORIGINS="https://my-site.example,http://localhost:3000"   (comma separated, no trailing /)
import inspect
import os

from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse

HLC_DEFAULT_ORIGINS = [
    "http://localhost:3000",  # the dashboard running locally (npm run dev / start)
    "http://127.0.0.1:3000",
    "http://localhost:8000",  # the engine's own /docs page
    "http://127.0.0.1:8000",
    PRODUCTION_SITE_ORIGIN,   # set at the top of this file (https://ciphercts.com)
    PRODUCTION_SITE_ORIGIN_WWW,
]


def _origin_ok(o):
    """Exact http(s) origins only. A wildcard never becomes an allowed origin."""
    if "*" in o:
        return False
    return o.startswith("http://") or o.startswith("https://")


def _hlc_origins():
    extra = [o.strip().rstrip("/") for o in os.environ.get("HLC_ALLOWED_ORIGINS", "").split(",") if o.strip()]
    allowed = [o.rstrip("/") for o in HLC_DEFAULT_ORIGINS + extra if _origin_ok(o.rstrip("/"))]
    return list(dict.fromkeys(allowed))


class _PrivateNetworkHeader:
    """Older Starlette only: answer Chrome's Private Network Access preflight for origins CORS accepted."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        wants = scope["type"] == "http" and scope.get("method") == "OPTIONS" and any(
            k.lower() == b"access-control-request-private-network" and v.lower() == b"true"
            for k, v in scope.get("headers", [])
        )
        if not wants:
            return await self.app(scope, receive, send)

        async def wrapped(message):
            if message["type"] == "http.response.start":
                hdrs = list(message.get("headers", []))
                if any(k.lower() == b"access-control-allow-origin" for k, _ in hdrs):
                    hdrs.append((b"access-control-allow-private-network", b"true"))
                message["headers"] = hdrs
            await send(message)

        await self.app(scope, receive, wrapped)


_cors_kwargs = dict(
    allow_origins=_hlc_origins(),
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type"],
    max_age=600,
)
if "allow_private_network" in inspect.signature(CORSMiddleware.__init__).parameters:
    _cors_kwargs["allow_private_network"] = True  # newer Starlette answers the PNA preflight itself
    app.add_middleware(CORSMiddleware, **_cors_kwargs)
else:
    app.add_middleware(CORSMiddleware, **_cors_kwargs)
    app.add_middleware(_PrivateNetworkHeader)  # added last = outermost


@app.get("/", include_in_schema=False)
def hlc_root():
    return RedirectResponse(url="/docs")


# --- end of HLC v1.1 patch -------------------------------------------------------------------------

# Initialize model locally on CPU from calibrated weights
predictor = LocalBioPredictor(weights_path='bio_engine_weights_nasa_v2.pt', dim=64)  # v2: weights trained on real NASA FD001

class TelemetryInput(BaseModel):
    # Expects 30 consecutive time steps across 21 sensors (30 x 21 matrix)
    sensor_stream: List[List[float]]

@app.get("/health")
def health():
    return {
        "status": "online",
        "engine": "7-Tier Hierarchical Latent Controller",
        "architecture": "Sushumna Spine + Meridian Mesh",
        "device": str(predictor.device),
        "weights": "nasa_v2"  # v2: lets the dashboard pick the matching normalisation
    }

@app.post("/predict")
def predict_rul(payload: TelemetryInput):
    data = np.array(payload.sensor_stream)
    if data.shape != (30, 21):
        raise HTTPException(
            status_code=400, 
            detail=f"Expected matrix of shape (30, 21), received {data.shape}"
        )
    result = predictor.predict_health(data)
    return result

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
