# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Cipher CTS
import os
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader

DATA_DIR = os.environ.get("HLC_DATA_DIR", "./cmapss_data")
TXT_PATH = os.path.join(DATA_DIR, "train_FD001.txt")

def load_data():
    # v2: REAL NASA C-MAPSS FD001 only. No network access and NO synthetic fallback (v1 silently generated
    # a fake "engine clone" when its download failed).
    if not os.path.exists(TXT_PATH):
        raise FileNotFoundError(
            f"Real NASA C-MAPSS file not found: {os.path.abspath(TXT_PATH)}\n"
            "Download CMAPSSData.zip from https://data.nasa.gov/docs/legacy/CMAPSSData.zip "
            "(or https://zenodo.org/records/15346912), unzip it, and copy train_FD001.txt, test_FD001.txt and "
            "RUL_FD001.txt into that folder (or set HLC_DATA_DIR). No synthetic data will be generated."
        )

    cols = ['unit', 'time', 'setting_1', 'setting_2', 'setting_3'] + [f'sensor_{i}' for i in range(1, 22)]
    df = pd.read_csv(TXT_PATH, sep=r'\s+', header=None, names=cols)

    max_times = df.groupby('unit')['time'].max().reset_index()
    max_times.rename(columns={'time': 'max_time'}, inplace=True)
    df = df.merge(max_times, on='unit')
    df['RUL'] = (df['max_time'] - df['time']).clip(upper=125.0)
    df.drop(columns=['max_time'], inplace=True)
    return df

class TurbofanDataset(Dataset):
    def __init__(self, df, seq_len=30):
        self.samples = []
        sensor_cols = [f'sensor_{i}' for i in range(1, 22)]
        
        df_norm = df.copy()
        s_min = df_norm[sensor_cols].min()
        s_max = df_norm[sensor_cols].max()
        df_norm[sensor_cols] = (df_norm[sensor_cols] - s_min) / (s_max - s_min + 1e-6)

        for _, group in df_norm.groupby('unit'):
            data = group[sensor_cols].values
            ruls = group['RUL'].values
            if len(data) >= seq_len:
                for i in range(len(data) - seq_len + 1):
                    self.samples.append((data[i:i+seq_len], ruls[i+seq_len-1]))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        x, y = self.samples[idx]
        return torch.tensor(x, dtype=torch.float32), torch.tensor(y, dtype=torch.float32)

class AcupointGate(nn.Module):
    def __init__(self, in_features, dim):
        super().__init__()
        self.proj = nn.Linear(in_features, dim)
        self.gate = nn.Linear(dim, dim)
        self.threshold = nn.Parameter(torch.tensor(0.10))

    def forward(self, x):
        h = self.proj(x)
        cond = torch.sigmoid(self.gate(h))
        mask = (cond > self.threshold).float()
        return h * cond * mask, cond.mean()

class EngineBioSystem(nn.Module):
    def __init__(self, dim=64):
        super().__init__()
        self.dim = dim
        self.chakras = nn.ModuleList([nn.GRUCell(dim, dim) for _ in range(7)])
        self.meridians = nn.ModuleList([
            AcupointGate(4, dim),
            AcupointGate(5, dim),
            AcupointGate(6, dim),
            AcupointGate(6, dim)
        ])
        self.meridian_targets = [0, 1, 2, 3]
        self.rul_head = nn.Sequential(
            nn.Linear(dim, 32),
            nn.ReLU(),
            nn.Linear(32, 1)
        )
        self.ojas = 1.0

    def forward_step(self, x_step, h_up, h_down, cut_solar=False):
        trunks = [
            x_step[:, 0:4],
            x_step[:, 4:9],
            x_step[:, 9:15],
            x_step[:, 15:21]
        ]
        
        raw_power = x_step.norm(dim=-1).mean().item()
        conductances = []
        lateral = {i: None for i in range(7)}

        for idx, meridian in enumerate(self.meridians):
            routed, cond = meridian(trunks[idx])
            conductances.append(cond)
            lateral[self.meridian_targets[idx]] = routed

        mean_cond = torch.stack(conductances).mean().item()
        self.ojas = max(1.0, min(8.0, self.ojas + 0.03 * max(0.0, raw_power - 1.0) - 0.01 * mean_cond - 0.02 * (self.ojas - 1.0)))

        up_carrier = torch.zeros(x_step.size(0), self.dim, device=x_step.device)
        for i in range(7):
            if cut_solar and i == 3:
                up_carrier = torch.zeros_like(up_carrier)

            lat = lateral[i]
            inp = up_carrier if lat is None else up_carrier + lat
            h_up[i] = self.chakras[i](inp, h_up[i])
            
            rms = torch.sqrt(torch.mean(h_up[i] ** 2, dim=-1, keepdim=True) + 1e-6)
            h_up[i] = (h_up[i] / rms) * (1.0 + 0.25 * self.ojas)
            up_carrier = h_up[i]

        down_prior = h_up[6]
        for i in reversed(range(6)):
            carrier_gate = torch.clamp(h_up[i].norm(dim=-1, keepdim=True) / (0.5 * (self.dim ** 0.5)), 0.0, 1.0)
            h_down[i] = h_down[i] * 0.8 + 0.2 * (down_prior * carrier_gate)
            down_prior = h_down[i]

        return self.rul_head(h_up[6]), h_up, h_down

    def forward(self, x_seq, cut_solar=False):
        batch_size, seq_len, _ = x_seq.shape
        h_up = [torch.zeros(batch_size, self.dim, device=x_seq.device) for _ in range(7)]
        h_down = [torch.zeros(batch_size, self.dim, device=x_seq.device) for _ in range(7)]
        pred = None
        for t in range(seq_len):
            pred, h_up, h_down = self.forward_step(x_seq[:, t, :], h_up, h_down, cut_solar=cut_solar)
        return pred.squeeze(-1), self.ojas

if __name__ == "__main__":
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[*] Engine initialized on device: {device}")

    df = load_data()
    dataset = TurbofanDataset(df, seq_len=30)
    train_size = int(0.8 * len(dataset))
    val_size = len(dataset) - train_size
    train_ds, val_ds = torch.utils.data.random_split(dataset, [train_size, val_size])

    train_loader = DataLoader(train_ds, batch_size=32, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=32, shuffle=False)

    model = EngineBioSystem(dim=64).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
    criterion = nn.MSELoss()

    print(f"[+] Loaded {len(dataset)} engine operational sequences.")
    print("[*] Training 7-Tier Bio-Engine for 5 epochs...\n")

    for epoch in range(1, 6):
        model.train()
        total_loss = 0.0
        final_ojas = 1.0

        for bx, by in train_loader:
            bx, by = bx.to(device), by.to(device)
            optimizer.zero_grad()
            pred, ojas = model(bx)
            loss = criterion(pred, by)
            loss.backward()
            optimizer.step()

            total_loss += loss.item()
            final_ojas = ojas

        train_rmse = np.sqrt(total_loss / len(train_loader))
        
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for vx, vy in val_loader:
                vx, vy = vx.to(device), vy.to(device)
                v_pred, _ = model(vx)
                val_loss += criterion(v_pred, vy).item()
        val_rmse = np.sqrt(val_loss / len(val_loader))

        print(f"Epoch {epoch:02d} | Train RMSE: {train_rmse:6.2f} cycles | Val RMSE: {val_rmse:6.2f} cycles | Ojas: {final_ojas:.3f}")

    print("\n[*] Evaluating Structural Integrity (Solar Plexus Cut on Telemetry)...")
    model.eval()
    normal_loss = 0.0
    severed_loss = 0.0
    with torch.no_grad():
        for vx, vy in val_loader:
            vx, vy = vx.to(device), vy.to(device)
            p_norm, _ = model(vx, cut_solar=False)
            p_cut, _ = model(vx, cut_solar=True)
            normal_loss += criterion(p_norm, vy).item()
            severed_loss += criterion(p_cut, vy).item()

    norm_rmse = np.sqrt(normal_loss / len(val_loader))
    cut_rmse = np.sqrt(severed_loss / len(val_loader))
    ratio = (cut_rmse / (norm_rmse + 1e-6))**2

    print(f"[-] Unbroken Val MSE:  {normal_loss / len(val_loader):.2f} (RMSE: {norm_rmse:.2f} cycles)")
    print(f"[!] Solar-Cut Val MSE: {severed_loss / len(val_loader):.2f} (RMSE: {cut_rmse:.2f} cycles)")
    print(f"[✓] Failure Divergence Ratio: {ratio:.2f}x error increase when spine is broken.")
