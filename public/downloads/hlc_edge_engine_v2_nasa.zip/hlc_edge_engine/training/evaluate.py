# © 2026 Cipher CTS. All Rights Reserved.
# Proprietary Evaluation License: see LICENSE.
"""Evaluate saved weights (strict load) on val engines and the OFFICIAL FD001 test set. Writes JSON."""
import argparse, json, os
import numpy as np, torch
from scipy.stats import spearmanr, pearsonr
from common import *

ap = argparse.ArgumentParser()
ap.add_argument('--weights', required=True)
ap.add_argument('--out', required=True)
ap.add_argument('--norm', default=None, help='norm_stats.json (default: refit from the 80 train engines)')
ap.add_argument('--n_orders', type=int, default=30)
a = ap.parse_args()
torch.set_num_threads(4)

df = load_train(); tr_u, va_u = split_units(df)
mn, mx = fit_norm(df[df.unit.isin(tr_u)])
if a.norm:
    s = json.load(open(a.norm)); mn = np.array(s['min']); mx = np.array(s['max'])
Xtr, ytr, _, _ = windows(df, mn, mx, tr_u)
train_mean = float(ytr.mean())

model = EngineBioSystem(dim=64)
model.load_state_dict(torch.load(a.weights, map_location='cpu'), strict=True)
model.eval()

R = {'weights': a.weights, 'train_mean_RUL_baseline_value': train_mean}

def block(pred, true_clipped, true_raw=None):
    d = dict(rmse_vs_clipped125=rmse(pred, true_clipped), score_vs_clipped125=nasa_score(pred, true_clipped), mae_vs_clipped125=float(np.mean(np.abs(pred - true_clipped))))
    if true_raw is not None:
        d.update(rmse_vs_raw=rmse(pred, true_raw), score_vs_raw=nasa_score(pred, true_raw))
    return d

# ---------------- validation engines (20 held-out units) ----------------
Xva, yva, Uva, Tva = windows(df, mn, mx, va_u)
pa, oa = predict(model, Xva, bs=1)                       # (a) fresh ojas, sequential, batch 1 (service-like)
pb, _ = predict(model, Xva, bs=1, reset_each=True)       # (b) diagnostic: ojas reset before every call
last = np.array([np.where(Uva == u)[0][-1] for u in va_u])
first = np.array([np.where(Uva == u)[0][0] for u in va_u])
R['val'] = dict(n_windows=len(Xva), engines=va_u,
    baseline_train_mean=block(np.full_like(yva, train_mean), yva),
    a_sequential_fresh_bs1=block(pa, yva), b_reset_each_diagnostic=block(pb, yva),
    last_window_per_engine_a=block(pa[last], yva[last]), last_window_per_engine_b=block(pb[last], yva[last]),
    baseline_last_window=block(np.full(len(last), train_mean), yva[last]),
    first_window_mean_pred_a=float(pa[first].mean()), last_window_mean_pred_a=float(pa[last].mean()),
    first_window_mean_pred_b=float(pb[first].mean()), last_window_mean_pred_b=float(pb[last].mean()),
    ojas_range_a=[float(oa.min()), float(oa.max())])

# ---------------- official test set ----------------
Xte, rul_raw, n_pad, lens = test_last_windows(mn, mx)
rul_clip = np.minimum(rul_raw, CLIP)
R['test'] = dict(n_engines=100, n_padded=int(n_pad), min_len=int(lens.min()), true_rul_raw_mean=float(rul_raw.mean()))
base = np.full(100, train_mean, np.float32)
R['test']['baseline_train_mean'] = block(base, rul_clip, rul_raw)
p_seq, o_seq = predict(model, Xte, bs=1)                            # (a) engine order 1..100, fresh start
p_rst, o_rst = predict(model, Xte, bs=1, reset_each=True)           # (b) diagnostic
p_b32, _ = predict(model, Xte, bs=32)
R['test']['a_sequential_fresh_bs1'] = block(p_seq, rul_clip, rul_raw)
R['test']['b_reset_each_diagnostic'] = block(p_rst, rul_clip, rul_raw)
R['test']['c_batch32_in_order_diagnostic'] = block(p_b32, rul_clip, rul_raw)
R['test']['ojas_range_a'] = [float(o_seq.min()), float(o_seq.max())]
R['test']['pred_a'] = [round(float(x), 3) for x in p_seq]; R['test']['pred_b'] = [round(float(x), 3) for x in p_rst]
R['test']['true_raw'] = rul_raw.tolist(); R['test']['ojas_a'] = [round(float(x), 4) for x in o_seq]
# order dependence
rng = np.random.RandomState(123)
rm, sc = [], []
for _ in range(a.n_orders):
    perm = rng.permutation(100)
    p, _ = predict(model, Xte[perm], bs=1)
    inv = np.empty(100, int); inv[perm] = np.arange(100)
    pp = p[inv]; rm.append(rmse(pp, rul_clip)); sc.append(nasa_score(pp, rul_raw))
rev, _ = predict(model, Xte[::-1].copy(), bs=1); rev = rev[::-1]
R['test']['order_dependence'] = dict(n_random_orders=a.n_orders, rmse_clipped_mean=float(np.mean(rm)), rmse_clipped_std=float(np.std(rm)),
    rmse_clipped_min=float(np.min(rm)), rmse_clipped_max=float(np.max(rm)), score_raw_min=float(np.min(sc)), score_raw_max=float(np.max(sc)),
    reverse_order=block(rev, rul_clip, rul_raw))
init = {}
for o0 in (1.0, 2.0, 4.0, 8.0):
    p, _ = predict(model, Xte, bs=1, ojas0=o0); init[str(o0)] = rmse(p, rul_clip)
R['test']['rmse_clipped_by_initial_ojas'] = init
# separation on test
for tag, p in (('a', p_seq), ('b', p_rst)):
    sp = spearmanr(p, rul_raw)[0]; pe = pearsonr(p, rul_raw)[0]
    bins = {}
    for lo, hi in ((0, 25), (25, 50), (50, 100), (100, 1000)):
        m = (rul_raw >= lo) & (rul_raw < hi)
        bins[f'true_{lo}-{hi}'] = dict(n=int(m.sum()), mean_pred=float(p[m].mean()) if m.any() else None,
                                     status_counts={s: int(sum(status(x) == s for x in p[m])) for s in ('CRITICAL', 'WARNING', 'NOMINAL')})
    R['test'][f'separation_{tag}'] = dict(spearman=float(sp), pearson=float(pe), bins=bins)

# ---------------- unit 1 healthy vs failing (unit 1 is a TRAIN engine) ----------------
g1 = df[df.unit == 1].sort_values('time'); d1 = apply_norm(g1[SENS].values.astype(np.float64), mn, mx).astype(np.float32)
h, f = d1[:30][None], d1[-30:][None]
def run(seq, reset):
    model.ojas = 1.0; out = []
    for x in seq:
        if reset: model.ojas = 1.0
        with torch.no_grad(): p, o = model(torch.from_numpy(x))
        out.append((float(p), float(o)))
    return out
u1 = {}
for name, seq, reset in (('healthy_then_failing_fresh', [h, f], False), ('failing_then_healthy_fresh', [f, h], False),
                         ('healthy_x5_then_failing', [h]*5 + [f], False), ('reset_each_healthy_failing', [h, f], True)):
    u1[name] = [dict(rul=round(p, 2), ojas=round(o, 3), status=status(p)) for p, o in run(seq, reset)]
u1['true_rul_first_window_end'] = float(min(len(g1) - 29, CLIP)); u1['true_rul_last_window_end'] = 0.0
R['unit1'] = u1
json.dump(R, open(a.out, 'w'), indent=1)
t = R['test']
print(f"VAL  a: rmse {R['val']['a_sequential_fresh_bs1']['rmse_vs_clipped125']:.3f}  b: {R['val']['b_reset_each_diagnostic']['rmse_vs_clipped125']:.3f}  baseline {R['val']['baseline_train_mean']['rmse_vs_clipped125']:.3f}")
print(f"TEST a: rmse(clip) {t['a_sequential_fresh_bs1']['rmse_vs_clipped125']:.3f} rmse(raw) {t['a_sequential_fresh_bs1']['rmse_vs_raw']:.3f} score(raw) {t['a_sequential_fresh_bs1']['score_vs_raw']:.0f}")
print(f"TEST b: rmse(clip) {t['b_reset_each_diagnostic']['rmse_vs_clipped125']:.3f} rmse(raw) {t['b_reset_each_diagnostic']['rmse_vs_raw']:.3f} score(raw) {t['b_reset_each_diagnostic']['score_vs_raw']:.0f}")
print(f"TEST baseline: rmse(clip) {t['baseline_train_mean']['rmse_vs_clipped125']:.3f} rmse(raw) {t['baseline_train_mean']['rmse_vs_raw']:.3f}")
print("order dep:", {k: (round(v, 3) if isinstance(v, float) else v) for k, v in t['order_dependence'].items() if k != 'reverse_order'})
print("unit1:", json.dumps(u1)[:600])
