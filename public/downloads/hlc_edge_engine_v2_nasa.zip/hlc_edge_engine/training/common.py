# © 2026 Cipher CTS. All Rights Reserved.
# Proprietary Evaluation License: see LICENSE.
"""Shared data/eval helpers for the HLC FD001 retrain. Real NASA data only - no synthetic fallback."""
import json, os, sys
import numpy as np, pandas as pd, torch
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, os.path.dirname(HERE))
from c_mapss_runner import EngineBioSystem  # Jim's class (byte-identical to v1)

# folder holding the REAL train_FD001.txt, test_FD001.txt, RUL_FD001.txt (see ../README.md); nothing is downloaded
DATA = os.environ.get("HLC_DATA_DIR", os.path.join(os.path.dirname(HERE), "cmapss_data"))
SEQ = 30
CLIP = 125.0
COLS = ['unit', 'time', 'setting_1', 'setting_2', 'setting_3'] + [f'sensor_{i}' for i in range(1, 22)]
SENS = [f'sensor_{i}' for i in range(1, 22)]
SPLIT_SEED = 0

def read(name):
    p = os.path.join(DATA, name)
    if not os.path.exists(p):
        raise FileNotFoundError(f"Real NASA file missing: {p}. No synthetic data is generated.")
    return pd.read_csv(p, sep=r'\s+', header=None, names=COLS)

def load_train():
    df = read('train_FD001.txt')
    mx = df.groupby('unit')['time'].transform('max')
    df['RUL'] = (mx - df['time']).clip(upper=CLIP)
    return df

def split_units(df, n_val=20, seed=SPLIT_SEED):
    units = np.array(sorted(df['unit'].unique()))
    rng = np.random.RandomState(seed)
    perm = rng.permutation(units)
    return sorted(perm[n_val:].tolist()), sorted(perm[:n_val].tolist())

def fit_norm(df_train_engines):
    mn = df_train_engines[SENS].min().values.astype(np.float64)
    mx = df_train_engines[SENS].max().values.astype(np.float64)
    return mn, mx

def apply_norm(x, mn, mx):
    """(x - min) / (max - min + 1e-6) for varying sensors (same formula as Jim's code);
    sensors with ZERO range in the training engines are forced to exactly 0.0
    (otherwise any later deviation would be divided by 1e-6 and explode)."""
    rng = mx - mn
    const = rng <= 0.0
    out = (x - mn) / (rng + 1e-6)
    out[..., const] = 0.0
    return out

def windows(df, mn, mx, units, with_rul=True):
    X, Y, U, T = [], [], [], []
    for u in units:
        g = df[df['unit'] == u].sort_values('time')
        d = apply_norm(g[SENS].values.astype(np.float64), mn, mx)
        r = g['RUL'].values if with_rul else None
        for i in range(len(d) - SEQ + 1):
            X.append(d[i:i+SEQ]); Y.append(r[i+SEQ-1]); U.append(u); T.append(g['time'].values[i+SEQ-1])
    return (np.asarray(X, np.float32), np.asarray(Y, np.float32), np.asarray(U), np.asarray(T))

def test_last_windows(mn, mx):
    """Last 30 cycles of each official test engine. Engines shorter than 30 cycles are
    padded at the FRONT by repeating their first row (none are shorter in FD001; asserted below)."""
    df = read('test_FD001.txt')
    rul = pd.read_csv(os.path.join(DATA, 'RUL_FD001.txt'), header=None)[0].values.astype(np.float32)
    X, n_padded, lens = [], 0, []
    for k, u in enumerate(sorted(df['unit'].unique())):
        g = df[df['unit'] == u].sort_values('time')
        d = apply_norm(g[SENS].values.astype(np.float64), mn, mx)
        lens.append(len(d))
        if len(d) < SEQ:
            d = np.concatenate([np.repeat(d[:1], SEQ - len(d), axis=0), d]); n_padded += 1
        X.append(d[-SEQ:])
    assert len(X) == len(rul) == 100
    return np.asarray(X, np.float32), rul, n_padded, np.asarray(lens)

def nasa_score(pred, true):
    d = np.asarray(pred, np.float64) - np.asarray(true, np.float64)
    return float(np.sum(np.where(d < 0, np.exp(-d / 13.0) - 1.0, np.exp(d / 10.0) - 1.0)))

def rmse(a, b):
    return float(np.sqrt(np.mean((np.asarray(a, np.float64) - np.asarray(b, np.float64)) ** 2)))

@torch.no_grad()
def predict(model, X, bs=256, reset_each=False, ojas0=1.0):
    """Predict in the given order. reset_each=True resets self.ojas to 1.0 before EVERY call (diagnostic only).
    Returns (preds, ojas_after_each_call)."""
    model.eval()
    model.ojas = ojas0
    P, O = [], []
    for i in range(0, len(X), bs):
        if reset_each:
            model.ojas = 1.0
        p, o = model(torch.from_numpy(X[i:i+bs]))
        P.append(p.numpy()); O += [float(o)] * len(p)
    return np.concatenate(P), np.asarray(O)

def status(rul):
    return "CRITICAL" if rul < 25 else ("WARNING" if rul < 50 else "NOMINAL")
