# © 2026 Cipher CTS. All Rights Reserved.
# Proprietary Evaluation License: see LICENSE.
"""Train EngineBioSystem(dim=64) on REAL NASA C-MAPSS FD001, split BY ENGINE UNIT.
Protocol (documented in RESULTS.md):
  * 80 train engines / 20 validation engines (np.random.RandomState(0) permutation of units 1..100).
  * MinMax stats from the 80 train engines only (zero-range sensors forced to 0).
  * Windows of 30 cycles, target = min(RUL,125) at the window's last cycle (same as Jim's script).
  * self.ojas starts at 1.0 at the beginning of training and is NEVER reset: it carries over across all
    mini-batches (shuffled each epoch, batch 32) exactly like Jim's loop. Before each validation pass the
    training ojas is saved; validation starts from a fresh ojas=1.0 and carries it sequentially through the
    validation windows (engine by engine, cycle order, batch 256); then the training ojas is restored.
  * Early stopping on validation-engine RMSE (all windows). The official test set is NEVER used here.
"""
import argparse, json, os, sys, time
import numpy as np, torch, torch.nn as nn
from common import *

ap = argparse.ArgumentParser()
ap.add_argument('--seed', type=int, required=True)
ap.add_argument('--epochs', type=int, default=80)
ap.add_argument('--patience', type=int, default=14)
ap.add_argument('--lr', type=float, default=1e-3)
ap.add_argument('--bs', type=int, default=32)
ap.add_argument('--threads', type=int, default=2)
ap.add_argument('--out', default=None)
a = ap.parse_args()
out = a.out or os.path.join(HERE, 'runs', f'seed{a.seed}')
os.makedirs(out, exist_ok=True)
torch.set_num_threads(a.threads)
torch.manual_seed(a.seed); np.random.seed(a.seed)

df = load_train()
tr_u, va_u = split_units(df)
mn, mx = fit_norm(df[df.unit.isin(tr_u)])
Xtr, ytr, _, _ = windows(df, mn, mx, tr_u)
Xva, yva, _, _ = windows(df, mn, mx, va_u)
print(f"train engines {len(tr_u)} windows {len(Xtr)} | val engines {len(va_u)} windows {len(Xva)} | train mean RUL {ytr.mean():.2f}", flush=True)

model = EngineBioSystem(dim=64)
with torch.no_grad():
    model.rul_head[2].bias.fill_(float(ytr.mean()))   # training init only (head starts at the mean)
opt = torch.optim.Adam(model.parameters(), lr=a.lr)
sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, factor=0.5, patience=4)
crit = nn.MSELoss()
Xtr_t, ytr_t = torch.from_numpy(Xtr), torch.from_numpy(ytr)
g = torch.Generator().manual_seed(a.seed)

best, best_ep, bad = 1e9, 0, 0
log = []
t0 = time.time()
for ep in range(1, a.epochs + 1):
    model.train()
    perm = torch.randperm(len(Xtr_t), generator=g)
    tot, n = 0.0, 0
    for i in range(0, len(perm), a.bs):
        idx = perm[i:i+a.bs]
        opt.zero_grad()
        pred, _ = model(Xtr_t[idx])
        loss = crit(pred, ytr_t[idx])
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 5.0)
        opt.step()
        tot += loss.item() * len(idx); n += len(idx)
    train_rmse = (tot / n) ** 0.5
    train_ojas = model.ojas
    pv, ov = predict(model, Xva)                      # fresh ojas=1.0, sequential
    model.ojas = train_ojas                            # restore training ojas (carry-over unbroken)
    val_rmse = rmse(pv, yva)
    sched.step(val_rmse)
    rec = dict(epoch=ep, train_rmse=train_rmse, val_rmse=val_rmse, lr=opt.param_groups[0]['lr'],
               train_ojas=train_ojas, val_ojas_mean=float(ov.mean()), secs=time.time() - t0)
    log.append(rec)
    flag = ''
    if val_rmse < best - 1e-4:
        best, best_ep, bad = val_rmse, ep, 0
        torch.save(model.state_dict(), os.path.join(out, 'best.pt')); flag = ' *'
    else:
        bad += 1
    print(f"ep {ep:03d} train {train_rmse:7.3f} val {val_rmse:7.3f} lr {rec['lr']:.1e} ojas(train) {train_ojas:.3f} ({rec['secs']:.0f}s){flag}", flush=True)
    json.dump(dict(args=vars(a), best_val_rmse=best, best_epoch=best_ep, log=log), open(os.path.join(out, 'log.json'), 'w'), indent=1)
    if bad >= a.patience:
        print(f"early stop at epoch {ep} (best {best:.3f} @ {best_ep})", flush=True); break
print(f"DONE best val RMSE {best:.3f} at epoch {best_ep}", flush=True)
