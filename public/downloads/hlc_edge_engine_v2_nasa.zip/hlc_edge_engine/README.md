# HLC Edge Engine — v2.0.1 (retrained on real NASA C-MAPSS FD001)

**© 2026 Cipher CTS. All Rights Reserved.**
**Evaluation & Benchmarking Build (Personal & Non-Commercial Use Only)** — licensed under the Cipher CTS Proprietary Evaluation License (see `LICENSE`).
Production, industrial fleet, or revenue-generating use requires a paid commercial license from Cipher CTS: **team@ciphercts.com**.

A small local web service for the 7-Tier Hierarchical Latent Controller (HLC) model.
It runs **on your own computer**, uses the **CPU only**, and listens on **127.0.0.1:8000** (not reachable from other machines).
The service itself makes no internet calls while running (the internet is only used to install packages on the first run).

**What is new in v2:** the weights (`bio_engine_weights_nasa_v2.pt`) were trained on the **real NASA C-MAPSS FD001** data, not on the synthetic
"engine clone" the v1 weights were fitted to. The model class (`EngineBioSystem(dim=64)`), the 30×21 input, the RUL cap of 125, the Ojas memory
and the API are unchanged. The v1/v1.1 weights are not in this zip (they are in the v1 / v1.1 downloads). `norm_stats.json` holds the min/max numbers
you must use to scale sensor data (below).

## Quick start (Linux / macOS / WSL)

Prerequisites: **Python 3.9 or newer** with `venv` (Linux Mint/Ubuntu: `sudo apt install python3 python3-venv python3-pip`),
about 1 GB of free disk space, and an internet connection for the first run only.

1. Unzip this folder and open a terminal inside it.
2. Run `bash run_engine.sh` (first run creates `./venv` and downloads CPU-only PyTorch, several hundred MB). It prints **ENGINE IS READY**.
3. Open **http://localhost:8000** (redirects to `/docs`). Health check: <http://localhost:8000/health>
   (v2 reports `"weights": "nasa_v2"`; the service version 2.0.1 shows on the `/docs` page).
4. Stop the engine with **Ctrl+C**.

## What the engine accepts — and how to scale your data (important)

`POST /predict` with `{"sensor_stream": [[...21 numbers...] x 30 rows]}` — exactly 30 time steps by 21 sensors, the 21 sensor columns of C-MAPSS
(`sensor_1` … `sensor_21`, in that order). The service does **not** normalise anything. Scale each column first:

```
x_scaled = (x - min) / (max - min + 1e-6)        # min and max per sensor from norm_stats.json
x_scaled = 0.0   for the 6 constant sensors listed under "zero_range_sensors" (1, 5, 10, 16, 18, 19)
```

* `min`/`max` come from the **80 training engines only** (the other 20 engines were held out for validation). Values are **not clipped**, so
  a reading outside the training range scales slightly below 0 or above 1; that is fine.
* Why the six constant sensors are forced to 0: they never change in FD001 (range 0). Dividing by `0 + 1e-6` would blow up any later deviation, so they are set to exactly 0.
* `test_calibrated_client.py` contains `LocalBioPredictor.normalize(raw)` which does exactly this.

The answer contains `predicted_remaining_life_cycles` (0…~125, the model predicts RUL capped at 125 cycles), `ojas_vitality_index` and a `status` (`NOMINAL`, `WARNING` or `CRITICAL`).

## Accuracy (measured; full details in RESULTS.md)

Measured on this build's weights, on CPU, with the **official FD001 test set** (the last 30 cycles of each of the 100 test engines, compared with
`RUL_FD001.txt`), a fresh engine and requests sent one after another (engines 1–100 in file order):

| | This model | Naive baseline (always predict the training-set mean, 80.43) |
| --- | --- | --- |
| Test RMSE vs official RUL (raw) | **15.29 cycles** | 41.84 |
| Test RMSE vs RUL capped at 125 | 13.75 cycles | 40.52 |
| NASA asymmetric score (raw RUL, lower is better) | **385** | 18461 |
| Validation RMSE (20 held-out engines, all windows) | 13.09 | 41.81 |

* Healthy vs failing: on the 100 test engines the mean predicted RUL was 16.9 for engines with true RUL 0–25, 36.2 for 25–50, 87.0 for 50–100 and
  111.6 for 100 and above (Pearson correlation 0.930, Spearman 0.866). For engine 1 of the training file, the first 30 cycles give ≈ 120 (NOMINAL) and the last 30 cycles ≈ 6 (CRITICAL).
* Engines close to failure: of the 19 test engines whose true RUL was below 25 cycles, **15 were reported CRITICAL, 4 WARNING and 0 NOMINAL**. So 4 of the 19 were *not*
  labelled CRITICAL; none were called NOMINAL. (One engine with a true RUL of 50–100 was also reported WARNING.)
* Four independent trainings (seeds 1–4, same split) gave test RMSE (raw) of 15.51, 15.29, 15.57 and 14.70 (mean 15.27, sd 0.40) and NASA scores 463, 385, 453, 345.
  The shipped weights are seed 2, picked because it had the lowest **validation** RMSE (not by test score).
* The figure of 9.02 RMSE that was reported for the original v1 weights was **not** reproduced for these weights or on the official test set. The original v1 weights
  gave no useful separation on real NASA data (measured earlier: ≈ 46 RMSE on the FD001 training file, no better than guessing the mean).
* **Limits:** FD001 is a simulation (one operating condition, one fault mode); FD002–FD004 were not tested. The validation set is only 20 engines. The test
  numbers are the official test set, but it is a single dataset and these numbers are not a guarantee on other data. The sensors must be scaled with `norm_stats.json`.

## Ojas accumulates across requests (by design)

The engine keeps a running "Ojas" value (a stress / thermal memory accumulator) **between requests**. The same input can give a slightly different answer the second time.
**Restarting the engine resets Ojas** (it starts at 1.0). The value is shared by everyone who talks to this engine. The v2 weights were trained with Ojas carried over between
batches (it settled around 2.1), so the model is calibrated for carried Ojas. Measured on the test set: resetting Ojas before every request (a diagnostic, not how the service works)
makes results worse (RMSE 17.83 vs 15.29 raw). The very first request after a restart is therefore a little less accurate than later ones. The order of requests matters only slightly:
over 50 random engine orders the RMSE (vs capped RUL) had mean 13.79, sd 0.12, range 13.58–14.22.
Example, healthy engine-1 window sent 5 times in a row: 120.25, 120.80, 121.02, 121.14, 121.21 (Ojas 1.51 → 2.07).

**Caveat (thread-safety):** that shared value is updated without locking. Sequential use is fine; concurrent requests give non-reproducible numbers. For a single local user this does not matter.

## Dataset provenance and terms

* **Data:** NASA **C-MAPSS** turbofan run-to-failure simulation, subset **FD001** (`train_FD001.txt`, `test_FD001.txt`, `RUL_FD001.txt`).
  Source used: `https://data.nasa.gov/docs/legacy/CMAPSSData.zip` (NASA Prognostics Center of Excellence data repository, "Turbofan Engine Degradation Simulation Data Set").
  The zip's md5 is `79a22f36e80606c69d0e9e4da5bb2b7a` (sha256 `74bef434…a34f`; `train_FD001.txt` sha256 `963b5e22825b34d8b21c69e1aeb4af3e647050eb672ee8834ba4b5d91d2de0f8`).
  The same md5 is listed on the NASA PCoE record at Zenodo: https://doi.org/10.5281/zenodo.15346912 .
* **License / terms:** the NASA data portal lists the dataset as public and states no explicit license; the Zenodo record states **CC BY 4.0**. Please cite
  A. Saxena, K. Goebel, D. Simon, N. Eklund, "Damage Propagation Modeling for Aircraft Engine Run-to-Failure Simulation", *Int. Conf. on Prognostics and Health Management (PHM08)*, 2008.
* **The dataset is NOT included in this zip.** The service does not need it. It is only needed to re-run the examples in `test_calibrated_client.py` or the scripts in `training/`:
  download the zip, unzip it and put the three FD001 files in `./cmapss_data/` (or point `HLC_DATA_DIR` at another folder). There is **no synthetic fallback**: if the files are missing
  the code stops with a clear error.

## Files

| File | What |
| --- | --- |
| `bio_engine_service.py` | The web service (v2: CORS block from v1.1 with the `PRODUCTION_SITE_ORIGIN` constant, version 2.0.1 on /docs, `weights` key in `/health`) |
| `bio_engine_weights_nasa_v2.pt` | Weights trained on real FD001 (loads with `strict=True`) |
| `norm_stats.json` | Per-sensor min/max (train engines only), zero-range sensors, split, data hashes |
| `c_mapss_runner.py` | The model class `EngineBioSystem` (unchanged) + data loader (no download, no synthetic data) |
| `test_calibrated_client.py` | `LocalBioPredictor` (strict load, applies `norm_stats.json`); run it with the data folder in place for a unit-1 demo |
| `RESULTS.md` | All measured training / evaluation numbers and the protocol |
| `training/` | `common.py`, `train.py`, `evaluate.py` to reproduce training (needs the data), plus the per-seed logs and `eval_final.json` |
| `docs/` | `diff_v1.1_to_v2.patch`, `diff_v1_to_v2_code.patch` — exactly what changed in the code |
| `LICENSE`, `NOTICE`, `THIRD_PARTY_NOTICES` | The Cipher CTS Proprietary Evaluation License, the notice file (© 2026 Cipher CTS. All Rights Reserved.) and the licenses of the third-party packages the engine installs |
| `run_engine.sh`, `requirements.txt`, `SHA256SUMS` | Start script, dependencies, checksums |

Reproduce: `cd training && python train.py --seed 2` then `python evaluate.py --weights runs/seed2/best.pt --norm <norm_stats.json> --out eval.json`
(training uses the shuffled batch order and the Ojas protocol documented in RESULTS.md; results vary a little by CPU and PyTorch version).

## CORS (letting a website's dashboard talk to the engine)

A web page can only read the engine's answers if the engine names that page's address ("origin"). Allowed by default:
`http://localhost:3000`, `http://127.0.0.1:3000` (the dashboard running on your own computer), `http://localhost:8000`, `http://127.0.0.1:8000`
(the engine's own `/docs` page), and the Cipher CTS production site `https://ciphercts.com` plus `https://www.ciphercts.com`.
**To change the production website: edit the constant `PRODUCTION_SITE_ORIGIN` at the top of `bio_engine_service.py`** (line 10, with a comment above it;
`PRODUCTION_SITE_ORIGIN_WWW` on line 11 is the `www.` address), or add sites without editing any file:

```bash
HLC_ALLOWED_ORIGINS="https://my-dashboard.example" bash run_engine.sh
```

(An origin is `https://host` plus a port if there is one, no path and no trailing slash.) A wildcard `*` is **never** accepted — it is dropped from both the constants and `HLC_ALLOWED_ORIGINS`, so a typo cannot open the engine to every website.
Chrome 142+ may ask you to allow "access to devices on your local network" the first time the dashboard connects — choose **Allow**.
Safari and some HTTPS-page setups can block pages from reaching `127.0.0.1`; if the dashboard stays OFFLINE, try Chrome/Edge/Firefox.

## Troubleshooting

| Problem | Fix |
| --- | --- |
| `python3: command not found` / venv error | `sudo apt install python3 python3-venv python3-pip` |
| Port 8000 already in use | The engine may already be running — open http://localhost:8000/docs — or stop the other program |
| Install is very slow | PyTorch is large; wait, or set `HLC_TORCH_INDEX` to a closer mirror |
| Dashboard says OFFLINE but the engine runs | Check the website's address is in the CORS list; allow local-network access in the browser prompt; try Chrome |
| `FileNotFoundError` mentioning `train_FD001.txt` | You ran a script that needs the real dataset; see "Dataset provenance" |
| Answers look meaningless (~100 for everything) | The input was not scaled with `norm_stats.json` |
| Want to start from scratch | Delete the `venv` folder and run `bash run_engine.sh` again |

## License

© 2026 Cipher CTS. All Rights Reserved.

This package is the **Evaluation & Benchmarking Build (Personal & Non-Commercial Use Only)**. It is licensed to you, not sold, under the
**Cipher CTS Proprietary Evaluation License, Version 1.0** (October 26, 2026): please read `LICENSE` before you use it. In short, you may install it on your own
computers for personal, non-commercial evaluation, testing and benchmarking. You may not use it in production, in an industrial fleet or for anything that earns revenue,
and you may not redistribute it, host it as a service, extract its weights, or use it or its outputs to train other models.

**Commercial use:** production, industrial fleet, or revenue-generating use requires a paid commercial license from Cipher CTS.
For fleet licensing and custom telemetry integration, contact **team@ciphercts.com**.

The license covers the **engine wrapper / service code** (`bio_engine_service.py`, `c_mapss_runner.py`, `test_calibrated_client.py`, `run_engine.sh`, the `training/` scripts)
and the **trained weights file** `bio_engine_weights_nasa_v2.pt`. Every `.py` file starts with the copyright line `© 2026 Cipher CTS. All Rights Reserved.`

* **The NASA C-MAPSS data is NOT included** in this package and is **not** covered by this license. It is public NASA data with its own terms and citation requirement; see
  "Dataset provenance and terms" above. The weights were trained from scratch by Cipher CTS on FD001, so please keep the citation when you publish results.
* PyTorch, FastAPI, NumPy, pandas and the other packages that `run_engine.sh` installs keep their own licenses; see `THIRD_PARTY_NOTICES`.
* The benchmark numbers are from simulated NASA FD001 data. This software is not safety-critical and must not be the sole basis for safety decisions.
