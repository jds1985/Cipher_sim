# © 2026 Cipher CTS. All Rights Reserved.
# Proprietary Evaluation License: see LICENSE.
import os
import json
import torch
import numpy as np
import pandas as pd
from c_mapss_runner import EngineBioSystem, load_data

# v2: the predictor loads weights STRICTLY and refuses to run without them (v1 printed an error and carried on
# with random weights). Inputs must be normalised with norm_stats.json - the service/predictor does NOT normalise.
SENSOR_COLS = [f'sensor_{i}' for i in range(1, 22)]

class LocalBioPredictor:
    def __init__(self, weights_path='bio_engine_weights_nasa_v2.pt', dim=64, norm_path='norm_stats.json'):
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.model = EngineBioSystem(dim=dim).to(self.device)
        if not os.path.exists(weights_path):
            raise FileNotFoundError(f"{weights_path} not found - refusing to run with random weights.")
        self.model.load_state_dict(torch.load(weights_path, map_location=self.device), strict=True)
        self.model.eval()
        self.norm = None
        if os.path.exists(norm_path):
            with open(norm_path) as f:
                self.norm = json.load(f)
        print("[+] Bio-Engine loaded calibrated weights successfully.")

    def normalize(self, raw_sensors):
        """raw (N,21) NASA sensor_1..sensor_21 values -> the 0..1 scale the weights were trained on."""
        if self.norm is None:
            raise FileNotFoundError("norm_stats.json not found next to the weights.")
        x = np.asarray(raw_sensors, dtype=np.float64)
        mn, mx = np.array(self.norm['min']), np.array(self.norm['max'])
        out = (x - mn) / (mx - mn + 1e-6)
        out[..., (mx - mn) <= 0.0] = 0.0   # sensors with zero range in training data stay exactly 0
        return out

    def predict_health(self, raw_sensor_stream_30_steps):
        tensor_in = torch.tensor(raw_sensor_stream_30_steps, dtype=torch.float32).unsqueeze(0).to(self.device)
        with torch.no_grad():
            rul_pred, ojas = self.model(tensor_in)
        rul_val = float(rul_pred.item())
        return {
            "predicted_remaining_life_cycles": round(rul_val, 2),
            "ojas_vitality_index": round(float(ojas), 3),
            "status": "CRITICAL" if rul_val < 25.0 else ("WARNING" if rul_val < 50.0 else "NOMINAL")
        }

if __name__ == "__main__":
    client = LocalBioPredictor()

    # Needs the REAL NASA file ./cmapss_data/train_FD001.txt (see README). Never downloads, never fakes data.
    df = load_data()

    # Engine Unit 1: first 30 cycles vs last 30 cycles before failure (unit 1 was a TRAINING engine)
    u1 = df[df['unit'] == 1]
    df_norm = client.normalize(u1[SENSOR_COLS].values)
    healthy_slice = df_norm[0:30]
    failing_slice = df_norm[len(u1) - 30:len(u1)]

    print("\n================ REAL TELEMETRY VERIFICATION ================")
    print("--- 1. Early life (first 30 cycles of unit 1; true RUL capped at 125) ---")
    res_healthy = client.predict_health(healthy_slice)
    print(f"Predicted Remaining Life : {res_healthy['predicted_remaining_life_cycles']} cycles")
    print(f"Ojas Vitality Index      : {res_healthy['ojas_vitality_index']}")
    print(f"Operating Status         : {res_healthy['status']}")

    print("\n--- 2. End of life (last 30 cycles of unit 1; true RUL at the last cycle = 0) ---")
    res_failing = client.predict_health(failing_slice)
    print(f"Predicted Remaining Life : {res_failing['predicted_remaining_life_cycles']} cycles")
    print(f"Ojas Vitality Index      : {res_failing['ojas_vitality_index']}")
    print(f"Operating Status         : {res_failing['status']}")
    print("Note: Ojas carries over between predictions in one process, so the second answer depends on the first.")
    print("=============================================================")
